--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Ubuntu 10.9-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.10 (Ubuntu 10.10-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX public.uidx_binary_objects_ref_count;
DROP INDEX public.uidx_binary_objects_hash;
DROP INDEX public.flyway_schema_history_s_idx;
ALTER TABLE ONLY public.flyway_schema_history DROP CONSTRAINT flyway_schema_history_pk;
ALTER TABLE ONLY public.binary_objects DROP CONSTRAINT binary_objects_pkey;
SELECT pg_catalog.lo_unlink('17576');
SELECT pg_catalog.lo_unlink('17575');
SELECT pg_catalog.lo_unlink('17574');
SELECT pg_catalog.lo_unlink('17569');
SELECT pg_catalog.lo_unlink('17566');
SELECT pg_catalog.lo_unlink('17565');
SELECT pg_catalog.lo_unlink('17563');
SELECT pg_catalog.lo_unlink('17562');
SELECT pg_catalog.lo_unlink('17561');
SELECT pg_catalog.lo_unlink('17560');
SELECT pg_catalog.lo_unlink('17558');
SELECT pg_catalog.lo_unlink('17552');
SELECT pg_catalog.lo_unlink('17546');
SELECT pg_catalog.lo_unlink('17544');
SELECT pg_catalog.lo_unlink('17542');
SELECT pg_catalog.lo_unlink('17540');
SELECT pg_catalog.lo_unlink('17538');
SELECT pg_catalog.lo_unlink('17535');
SELECT pg_catalog.lo_unlink('17534');
SELECT pg_catalog.lo_unlink('17533');
SELECT pg_catalog.lo_unlink('17528');
SELECT pg_catalog.lo_unlink('17526');
SELECT pg_catalog.lo_unlink('17522');
SELECT pg_catalog.lo_unlink('17521');
SELECT pg_catalog.lo_unlink('17520');
SELECT pg_catalog.lo_unlink('17515');
SELECT pg_catalog.lo_unlink('17509');
SELECT pg_catalog.lo_unlink('17508');
SELECT pg_catalog.lo_unlink('17507');
SELECT pg_catalog.lo_unlink('17506');
SELECT pg_catalog.lo_unlink('17505');
SELECT pg_catalog.lo_unlink('17504');
SELECT pg_catalog.lo_unlink('17503');
SELECT pg_catalog.lo_unlink('17502');
SELECT pg_catalog.lo_unlink('17501');
SELECT pg_catalog.lo_unlink('17500');
SELECT pg_catalog.lo_unlink('17437');
SELECT pg_catalog.lo_unlink('17435');
SELECT pg_catalog.lo_unlink('17344');
SELECT pg_catalog.lo_unlink('17343');
SELECT pg_catalog.lo_unlink('17342');
SELECT pg_catalog.lo_unlink('17341');
SELECT pg_catalog.lo_unlink('17327');
SELECT pg_catalog.lo_unlink('17325');
SELECT pg_catalog.lo_unlink('17305');
SELECT pg_catalog.lo_unlink('17301');
SELECT pg_catalog.lo_unlink('17300');
SELECT pg_catalog.lo_unlink('17299');
SELECT pg_catalog.lo_unlink('17296');
SELECT pg_catalog.lo_unlink('17295');
SELECT pg_catalog.lo_unlink('17294');
SELECT pg_catalog.lo_unlink('17293');
SELECT pg_catalog.lo_unlink('17292');
SELECT pg_catalog.lo_unlink('17291');
SELECT pg_catalog.lo_unlink('17277');
SELECT pg_catalog.lo_unlink('17267');
SELECT pg_catalog.lo_unlink('17266');
SELECT pg_catalog.lo_unlink('17220');
SELECT pg_catalog.lo_unlink('17219');
SELECT pg_catalog.lo_unlink('17218');
SELECT pg_catalog.lo_unlink('17102');
SELECT pg_catalog.lo_unlink('17101');
SELECT pg_catalog.lo_unlink('17100');
SELECT pg_catalog.lo_unlink('17099');
SELECT pg_catalog.lo_unlink('17094');
SELECT pg_catalog.lo_unlink('17091');
SELECT pg_catalog.lo_unlink('17089');
SELECT pg_catalog.lo_unlink('17083');
SELECT pg_catalog.lo_unlink('17081');
SELECT pg_catalog.lo_unlink('17080');
SELECT pg_catalog.lo_unlink('17079');
SELECT pg_catalog.lo_unlink('17078');
SELECT pg_catalog.lo_unlink('17077');
SELECT pg_catalog.lo_unlink('17075');
SELECT pg_catalog.lo_unlink('17074');
SELECT pg_catalog.lo_unlink('17060');
SELECT pg_catalog.lo_unlink('17058');
SELECT pg_catalog.lo_unlink('17036');
SELECT pg_catalog.lo_unlink('17035');
SELECT pg_catalog.lo_unlink('17034');
SELECT pg_catalog.lo_unlink('17033');
SELECT pg_catalog.lo_unlink('17032');
SELECT pg_catalog.lo_unlink('17031');
SELECT pg_catalog.lo_unlink('17030');
SELECT pg_catalog.lo_unlink('17029');
SELECT pg_catalog.lo_unlink('17028');
SELECT pg_catalog.lo_unlink('17015');
SELECT pg_catalog.lo_unlink('17014');
SELECT pg_catalog.lo_unlink('17000');
SELECT pg_catalog.lo_unlink('16998');
SELECT pg_catalog.lo_unlink('16997');
SELECT pg_catalog.lo_unlink('16995');
SELECT pg_catalog.lo_unlink('16994');
SELECT pg_catalog.lo_unlink('16985');
SELECT pg_catalog.lo_unlink('16984');
SELECT pg_catalog.lo_unlink('16983');
SELECT pg_catalog.lo_unlink('16981');
SELECT pg_catalog.lo_unlink('16980');
SELECT pg_catalog.lo_unlink('16979');
SELECT pg_catalog.lo_unlink('16978');
SELECT pg_catalog.lo_unlink('16977');
SELECT pg_catalog.lo_unlink('16976');
SELECT pg_catalog.lo_unlink('16975');
SELECT pg_catalog.lo_unlink('16974');
SELECT pg_catalog.lo_unlink('16973');
SELECT pg_catalog.lo_unlink('16969');
SELECT pg_catalog.lo_unlink('16967');
SELECT pg_catalog.lo_unlink('16966');
SELECT pg_catalog.lo_unlink('16965');
SELECT pg_catalog.lo_unlink('16961');
SELECT pg_catalog.lo_unlink('16960');
SELECT pg_catalog.lo_unlink('16959');
SELECT pg_catalog.lo_unlink('16958');
SELECT pg_catalog.lo_unlink('16957');
SELECT pg_catalog.lo_unlink('16956');
SELECT pg_catalog.lo_unlink('16955');
SELECT pg_catalog.lo_unlink('16953');
SELECT pg_catalog.lo_unlink('16952');
SELECT pg_catalog.lo_unlink('16951');
SELECT pg_catalog.lo_unlink('16950');
SELECT pg_catalog.lo_unlink('16949');
SELECT pg_catalog.lo_unlink('16948');
SELECT pg_catalog.lo_unlink('16947');
SELECT pg_catalog.lo_unlink('16945');
SELECT pg_catalog.lo_unlink('16944');
SELECT pg_catalog.lo_unlink('16943');
SELECT pg_catalog.lo_unlink('16942');
SELECT pg_catalog.lo_unlink('16941');
SELECT pg_catalog.lo_unlink('16940');
SELECT pg_catalog.lo_unlink('16939');
SELECT pg_catalog.lo_unlink('16938');
SELECT pg_catalog.lo_unlink('16937');
SELECT pg_catalog.lo_unlink('16936');
SELECT pg_catalog.lo_unlink('16935');
SELECT pg_catalog.lo_unlink('16933');
SELECT pg_catalog.lo_unlink('16931');
SELECT pg_catalog.lo_unlink('16930');
SELECT pg_catalog.lo_unlink('16929');
SELECT pg_catalog.lo_unlink('16928');
SELECT pg_catalog.lo_unlink('16927');
SELECT pg_catalog.lo_unlink('16926');
SELECT pg_catalog.lo_unlink('16924');
SELECT pg_catalog.lo_unlink('16923');
SELECT pg_catalog.lo_unlink('16922');
SELECT pg_catalog.lo_unlink('16915');
SELECT pg_catalog.lo_unlink('16913');
SELECT pg_catalog.lo_unlink('16912');
SELECT pg_catalog.lo_unlink('16911');
SELECT pg_catalog.lo_unlink('16909');
SELECT pg_catalog.lo_unlink('16905');
SELECT pg_catalog.lo_unlink('16904');
SELECT pg_catalog.lo_unlink('16903');
SELECT pg_catalog.lo_unlink('16902');
SELECT pg_catalog.lo_unlink('16901');
SELECT pg_catalog.lo_unlink('16900');
SELECT pg_catalog.lo_unlink('16899');
SELECT pg_catalog.lo_unlink('16898');
SELECT pg_catalog.lo_unlink('16897');
SELECT pg_catalog.lo_unlink('16896');
SELECT pg_catalog.lo_unlink('16895');
SELECT pg_catalog.lo_unlink('16894');
SELECT pg_catalog.lo_unlink('16893');
SELECT pg_catalog.lo_unlink('16892');
SELECT pg_catalog.lo_unlink('16890');
SELECT pg_catalog.lo_unlink('16889');
SELECT pg_catalog.lo_unlink('16888');
SELECT pg_catalog.lo_unlink('16887');
SELECT pg_catalog.lo_unlink('16886');
SELECT pg_catalog.lo_unlink('16885');
SELECT pg_catalog.lo_unlink('16884');
SELECT pg_catalog.lo_unlink('16883');
SELECT pg_catalog.lo_unlink('16882');
SELECT pg_catalog.lo_unlink('16881');
SELECT pg_catalog.lo_unlink('16880');
SELECT pg_catalog.lo_unlink('16879');
SELECT pg_catalog.lo_unlink('16878');
SELECT pg_catalog.lo_unlink('16877');
SELECT pg_catalog.lo_unlink('16876');
SELECT pg_catalog.lo_unlink('16875');
SELECT pg_catalog.lo_unlink('16874');
SELECT pg_catalog.lo_unlink('16873');
SELECT pg_catalog.lo_unlink('16872');
SELECT pg_catalog.lo_unlink('16871');
SELECT pg_catalog.lo_unlink('16870');
SELECT pg_catalog.lo_unlink('16869');
SELECT pg_catalog.lo_unlink('16868');
SELECT pg_catalog.lo_unlink('16867');
SELECT pg_catalog.lo_unlink('16866');
SELECT pg_catalog.lo_unlink('16864');
SELECT pg_catalog.lo_unlink('16863');
SELECT pg_catalog.lo_unlink('16862');
SELECT pg_catalog.lo_unlink('16860');
SELECT pg_catalog.lo_unlink('16858');
SELECT pg_catalog.lo_unlink('16857');
SELECT pg_catalog.lo_unlink('16833');
SELECT pg_catalog.lo_unlink('16832');
SELECT pg_catalog.lo_unlink('16831');
SELECT pg_catalog.lo_unlink('16815');
SELECT pg_catalog.lo_unlink('16813');
SELECT pg_catalog.lo_unlink('16812');
SELECT pg_catalog.lo_unlink('16811');
SELECT pg_catalog.lo_unlink('16809');
SELECT pg_catalog.lo_unlink('16808');
SELECT pg_catalog.lo_unlink('16807');
SELECT pg_catalog.lo_unlink('16806');
SELECT pg_catalog.lo_unlink('16804');
SELECT pg_catalog.lo_unlink('16803');
SELECT pg_catalog.lo_unlink('16802');
SELECT pg_catalog.lo_unlink('16801');
SELECT pg_catalog.lo_unlink('16800');
SELECT pg_catalog.lo_unlink('16799');
SELECT pg_catalog.lo_unlink('16798');
SELECT pg_catalog.lo_unlink('16796');
SELECT pg_catalog.lo_unlink('16795');
SELECT pg_catalog.lo_unlink('16794');
SELECT pg_catalog.lo_unlink('16790');
SELECT pg_catalog.lo_unlink('16788');
SELECT pg_catalog.lo_unlink('16787');
SELECT pg_catalog.lo_unlink('16786');
SELECT pg_catalog.lo_unlink('16784');
SELECT pg_catalog.lo_unlink('16783');
SELECT pg_catalog.lo_unlink('16782');
SELECT pg_catalog.lo_unlink('16781');
SELECT pg_catalog.lo_unlink('16780');
SELECT pg_catalog.lo_unlink('16779');
SELECT pg_catalog.lo_unlink('16778');
SELECT pg_catalog.lo_unlink('16777');
SELECT pg_catalog.lo_unlink('16776');
SELECT pg_catalog.lo_unlink('16775');
SELECT pg_catalog.lo_unlink('16774');
SELECT pg_catalog.lo_unlink('16771');
SELECT pg_catalog.lo_unlink('16769');
SELECT pg_catalog.lo_unlink('16768');
SELECT pg_catalog.lo_unlink('16767');
SELECT pg_catalog.lo_unlink('16766');
SELECT pg_catalog.lo_unlink('16765');
SELECT pg_catalog.lo_unlink('16764');
SELECT pg_catalog.lo_unlink('16762');
SELECT pg_catalog.lo_unlink('16761');
SELECT pg_catalog.lo_unlink('16760');
SELECT pg_catalog.lo_unlink('16759');
SELECT pg_catalog.lo_unlink('16758');
SELECT pg_catalog.lo_unlink('16757');
SELECT pg_catalog.lo_unlink('16756');
SELECT pg_catalog.lo_unlink('16755');
SELECT pg_catalog.lo_unlink('16749');
SELECT pg_catalog.lo_unlink('16748');
SELECT pg_catalog.lo_unlink('16747');
SELECT pg_catalog.lo_unlink('16746');
SELECT pg_catalog.lo_unlink('16745');
SELECT pg_catalog.lo_unlink('16744');
SELECT pg_catalog.lo_unlink('16740');
SELECT pg_catalog.lo_unlink('16738');
SELECT pg_catalog.lo_unlink('16737');
SELECT pg_catalog.lo_unlink('16734');
SELECT pg_catalog.lo_unlink('16732');
SELECT pg_catalog.lo_unlink('16731');
SELECT pg_catalog.lo_unlink('16730');
SELECT pg_catalog.lo_unlink('16729');
SELECT pg_catalog.lo_unlink('16728');
SELECT pg_catalog.lo_unlink('16725');
SELECT pg_catalog.lo_unlink('16721');
SELECT pg_catalog.lo_unlink('16717');
SELECT pg_catalog.lo_unlink('16716');
SELECT pg_catalog.lo_unlink('16712');
SELECT pg_catalog.lo_unlink('16708');
SELECT pg_catalog.lo_unlink('16707');
SELECT pg_catalog.lo_unlink('16704');
SELECT pg_catalog.lo_unlink('16702');
SELECT pg_catalog.lo_unlink('16700');
SELECT pg_catalog.lo_unlink('16699');
SELECT pg_catalog.lo_unlink('16698');
SELECT pg_catalog.lo_unlink('16695');
SELECT pg_catalog.lo_unlink('16693');
SELECT pg_catalog.lo_unlink('16689');
SELECT pg_catalog.lo_unlink('16688');
SELECT pg_catalog.lo_unlink('16685');
SELECT pg_catalog.lo_unlink('16683');
SELECT pg_catalog.lo_unlink('16682');
SELECT pg_catalog.lo_unlink('16680');
ALTER TABLE public.binary_objects ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.flyway_schema_history;
DROP SEQUENCE public.binary_objects_id_seq;
DROP TABLE public.binary_objects;
DROP FUNCTION public.bsx_error_src_self();
DROP FUNCTION public.bsx_error_src_none();
DROP FUNCTION public.bsx_error_src_blob_update();
DROP FUNCTION public.bsx_error_src_blob_store();
DROP FUNCTION public.bsx_error_src_blob_retrieve();
DROP FUNCTION public.bsx_error_src_blob_restore();
DROP FUNCTION public.bsx_error_src_blob_delete();
DROP FUNCTION public.bsx_error_src_blob_append();
DROP FUNCTION public.bsx_error_ctx_ref_counts();
DROP FUNCTION public.bsx_error_ctx_none();
DROP FUNCTION public.bsx_error_ctx_identifier();
DROP FUNCTION public.bsx_error_ctx_hash_list();
DROP FUNCTION public.bsx_error_code_success_new();
DROP FUNCTION public.bsx_error_code_success_exists();
DROP FUNCTION public.bsx_error_code_not_found();
DROP FUNCTION public.bsx_error_code_invalid_argument();
DROP FUNCTION public.bs_blob_update(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer);
DROP FUNCTION public.bs_blob_store(phash bytea, poid oid, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer);
DROP FUNCTION public.bs_blob_retrieve_by_hash(phash bytea, OUT pbytes bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer);
DROP FUNCTION public.bs_blob_retrieve(pid bigint, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer);
DROP FUNCTION public.bs_blob_restore(prefcounts bigint[], pblobhashes bytea[], OUT pids bigint[], OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer);
DROP FUNCTION public.bs_blob_lookup_id_by_hash(phash bytea, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer);
DROP FUNCTION public.bs_blob_increment_ref_count(pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer);
DROP FUNCTION public.bs_blob_exists(phash bytea);
DROP FUNCTION public.bs_blob_delete_trigger();
DROP FUNCTION public.bs_blob_delete(pid bigint, OUT pdeleted boolean, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer);
DROP FUNCTION public.bs_blob_append(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer);
DROP EXTENSION pgcrypto;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA crypto;
--
-- Name: crypto; Type: SCHEMA; Schema: -; Owner: swirlds
--

CREATE SCHEMA crypto;


ALTER SCHEMA crypto OWNER TO swirlds;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA crypto;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: bs_blob_append(bigint, bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_append(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	newContent      bytea;
	deleteErrorCode int;
	deleteErrorSrc  int[];
	deleteErrorCtx  int;
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_append()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	-- 	select (obj.content || pBytes) from binary_objects as obj where obj.id = pId for share into newContent;
--
-- 	if newContent is null then
-- 		pErrorCode := bsx_error_code_not_found();
-- 		pErrorCtx := bsx_error_ctx_identifier();
-- 		return;
-- 	end if;
--
-- 	select sto.pId, sto.pHash
-- 	from bs_blob_store(newContent) as sto into pNewId, pHash;
--
-- 	select del.pErrorCode, del.pErrorSrc, del.pErrorCtx
-- 	from bs_blob_delete(pId) as del into deleteErrorCode, deleteErrorSrc, deleteErrorCtx;

-- 	if deleteErrorCode != bsx_error_code_success_exists() then
-- 		pErrorCode := deleteErrorCode;
-- 		pErrorSrc := deleteErrorSrc;
-- 		pErrorCtx := deleteErrorCtx;
-- 		return;
-- 	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_append(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_delete(bigint); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_delete(pid bigint, OUT pdeleted boolean, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	currentRefCount bigint;
	currentId       bigint;
-- 	current         int;
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_delete()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	pDeleted := false;

	select id, ref_count from binary_objects where id = pId into currentId, currentRefCount;

	if currentId is null or currentId <= 0 then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

	if currentRefCount <= 1 then
		delete from binary_objects where id = pId returning id, file_oid into currentId, pOid;
		pDeleted := true;
	else
		update binary_objects set ref_count = ref_count - 1 where id = pId returning id, file_oid into currentId, pOid;
	end if;


	if currentId is null or currentId <= 0 then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_delete(pid bigint, OUT pdeleted boolean, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_delete_trigger(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_delete_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
	result int;
begin
	select lo_unlink(old.file_oid) into result;
	return new;
end;
$$;


ALTER FUNCTION public.bs_blob_delete_trigger() OWNER TO swirlds;

--
-- Name: bs_blob_exists(bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_exists(phash bytea) RETURNS bigint
    LANGUAGE plpgsql STABLE
    AS $$
begin
	return (select bo.id from binary_objects as bo where hash = pHash limit 1);
end;
$$;


ALTER FUNCTION public.bs_blob_exists(phash bytea) OWNER TO swirlds;

--
-- Name: bs_blob_increment_ref_count(bigint); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_increment_ref_count(pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	currentRefCount bigint;
	currentId       bigint;
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_delete()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	select ref_count from binary_objects where id = pId into currentRefCount;

	if currentRefCount > 0 then
		update binary_objects set ref_count = ref_count + 1 where id = pId returning id, file_oid into currentId;
	end if;


	if currentId is null or currentId <= 0 then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_increment_ref_count(pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_lookup_id_by_hash(bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_lookup_id_by_hash(phash bytea, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_retrieve()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	select obj.id from binary_objects as obj where obj.hash = pHash into pId;

	if pId is null then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_lookup_id_by_hash(phash bytea, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_restore(bigint[], bytea[]); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_restore(prefcounts bigint[], pblobhashes bytea[], OUT pids bigint[], OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	deletedObjects bigint[];
begin

	pErrorCode := bsx_error_code_success_new();
	pErrorSrc := array [bsx_error_src_blob_restore()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	if pRefCounts is null or array_length(pRefCounts, 1) <= 0 then
		pErrorCode := bsx_error_code_invalid_argument();
		pErrorCtx := bsx_error_ctx_hash_list();
		return;
	end if;

	if pBlobHashes is null or not array_length(pBlobHashes, 1) = array_length(pRefCounts, 1) then
		pErrorCode := bsx_error_code_invalid_argument();
		pErrorCtx := bsx_error_ctx_ref_counts();
		return;
	end if;

	update binary_objects as b set ref_count = 0 where not b.ref_count = 0;

	with inserts as (
		update binary_objects as b set ref_count = t.ref_count
			from unnest(pRefCounts, pBlobHashes) with ordinality as t(ref_count, hash, idx)
			where b.hash = t.hash
			returning id, t.idx
	)
	select array_agg(sorted_ids.id)
	from (
			 select ti.id
			 from inserts as ti
			 order by ti.idx) as sorted_ids
	into pIds;


	with cleanup as (
		select obj.id, obj.file_oid from binary_objects as obj where obj.ref_count = 0
	), purge as (
		select lo_unlink(cl.file_oid), cl.id
		from cleanup as cl
	)
	select array_agg(array [pg.id]::bigint[])
	from purge as pg into deletedObjects;

	delete from binary_objects where id = any(deletedObjects);

end;
$$;


ALTER FUNCTION public.bs_blob_restore(prefcounts bigint[], pblobhashes bytea[], OUT pids bigint[], OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_retrieve(bigint); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_retrieve(pid bigint, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_retrieve()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	select obj.file_oid from binary_objects as obj where obj.id = pId into pOid;

	if pOid is null then
		pErrorCode := bsx_error_code_not_found();
		pErrorCtx := bsx_error_ctx_identifier();
		return;
	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_retrieve(pid bigint, OUT poid oid, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_retrieve_by_hash(bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_retrieve_by_hash(phash bytea, OUT pbytes bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_retrieve()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	-- 	select obj.content from binary_objects as obj where obj.hash = pHash into pBytes;

-- 	if pBytes is null then
-- 		pErrorCode := bsx_error_code_not_found();
-- 		pErrorCtx := bsx_error_ctx_identifier();
-- 		return;
-- 	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_retrieve_by_hash(phash bytea, OUT pbytes bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_store(bytea, oid); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_store(phash bytea, poid oid, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	foundId      bigint;
	unlinkResult int;
	currentOid   oid;
begin

	pErrorCode := bsx_error_code_success_new();
	pErrorSrc := array [bsx_error_src_blob_store()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	select bo.id, bo.file_oid from binary_objects as bo where hash = pHash into foundId, currentOid;

	if foundId is not null and foundId > 0 then
		if currentOid is not null and pOid is not null and not pOid = currentOid then
			select fx from lo_unlink(pOid) as fx into unlinkResult;
		end if;

		update binary_objects set ref_count = ref_count + 1 where id = foundId returning id into pId;
	else
		insert into binary_objects (id, ref_count, hash, file_oid)
		values (DEFAULT, 1, pHash, pOid) returning id into pId;
	end if;


end ;
$$;


ALTER FUNCTION public.bs_blob_store(phash bytea, poid oid, OUT pid bigint, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bs_blob_update(bigint, bytea); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bs_blob_update(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) RETURNS record
    LANGUAGE plpgsql
    AS $$
declare
	currentId bigint;
begin

	pErrorCode := bsx_error_code_success_exists();
	pErrorSrc := array [bsx_error_src_blob_update()]::int[];
	pErrorCtx := bsx_error_ctx_none();

	-- 	select obj.id from binary_objects as obj where obj.id = pId for update into currentId;
--
-- 	if currentId is null or currentId <= 0 then
-- 		pErrorCode := bsx_error_code_not_found();
-- 		pErrorCtx := bsx_error_ctx_identifier();
-- 		return;
-- 	end if;
--
-- 	select fx.pId, fx.pHash, fx.pErrorCode, fx.pErrorSrc, fx.pErrorCtx
-- 	from bs_blob_store(pBytes) as fx into pNewId, pHash, pErrorCode, pErrorSrc, pErrorCtx;
--
-- 	if pErrorCode < 0 then
-- 		return;
-- 	end if;
--
-- 	select fx.pErrorCode, fx.pErrorSrc, fx.pErrorCtx
-- 	from bs_blob_delete(pId) as fx into pErrorCode, pErrorSrc, pErrorCtx;
--
-- 	if pErrorCode < 0 then
-- 		return;
-- 	end if;

end;
$$;


ALTER FUNCTION public.bs_blob_update(pid bigint, pbytes bytea, OUT pnewid bigint, OUT phash bytea, OUT perrorcode integer, OUT perrorsrc integer[], OUT perrorctx integer) OWNER TO swirlds;

--
-- Name: bsx_error_code_invalid_argument(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_code_invalid_argument() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select -2;
$$;


ALTER FUNCTION public.bsx_error_code_invalid_argument() OWNER TO swirlds;

--
-- Name: bsx_error_code_not_found(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_code_not_found() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select -1;
$$;


ALTER FUNCTION public.bsx_error_code_not_found() OWNER TO swirlds;

--
-- Name: bsx_error_code_success_exists(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_code_success_exists() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 0;
$$;


ALTER FUNCTION public.bsx_error_code_success_exists() OWNER TO swirlds;

--
-- Name: bsx_error_code_success_new(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_code_success_new() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1;
$$;


ALTER FUNCTION public.bsx_error_code_success_new() OWNER TO swirlds;

--
-- Name: bsx_error_ctx_hash_list(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_ctx_hash_list() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1026;
$$;


ALTER FUNCTION public.bsx_error_ctx_hash_list() OWNER TO swirlds;

--
-- Name: bsx_error_ctx_identifier(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_ctx_identifier() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1025;
$$;


ALTER FUNCTION public.bsx_error_ctx_identifier() OWNER TO swirlds;

--
-- Name: bsx_error_ctx_none(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_ctx_none() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1024;
$$;


ALTER FUNCTION public.bsx_error_ctx_none() OWNER TO swirlds;

--
-- Name: bsx_error_ctx_ref_counts(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_ctx_ref_counts() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 1027;
$$;


ALTER FUNCTION public.bsx_error_ctx_ref_counts() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_append(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_append() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4100;
$$;


ALTER FUNCTION public.bsx_error_src_blob_append() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_delete(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_delete() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4102;
$$;


ALTER FUNCTION public.bsx_error_src_blob_delete() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_restore(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_restore() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4103;
$$;


ALTER FUNCTION public.bsx_error_src_blob_restore() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_retrieve(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_retrieve() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4098;
$$;


ALTER FUNCTION public.bsx_error_src_blob_retrieve() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_store(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_store() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4099;
$$;


ALTER FUNCTION public.bsx_error_src_blob_store() OWNER TO swirlds;

--
-- Name: bsx_error_src_blob_update(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_blob_update() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4101;
$$;


ALTER FUNCTION public.bsx_error_src_blob_update() OWNER TO swirlds;

--
-- Name: bsx_error_src_none(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_none() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4096;
$$;


ALTER FUNCTION public.bsx_error_src_none() OWNER TO swirlds;

--
-- Name: bsx_error_src_self(); Type: FUNCTION; Schema: public; Owner: swirlds
--

CREATE FUNCTION public.bsx_error_src_self() RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$
select 4097;
$$;


ALTER FUNCTION public.bsx_error_src_self() OWNER TO swirlds;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: binary_objects; Type: TABLE; Schema: public; Owner: swirlds
--

CREATE TABLE public.binary_objects (
    id bigint NOT NULL,
    ref_count bigint DEFAULT 1 NOT NULL,
    hash bytea NOT NULL,
    file_oid oid NOT NULL
);


ALTER TABLE public.binary_objects OWNER TO swirlds;

--
-- Name: binary_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: swirlds
--

CREATE SEQUENCE public.binary_objects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.binary_objects_id_seq OWNER TO swirlds;

--
-- Name: binary_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: swirlds
--

ALTER SEQUENCE public.binary_objects_id_seq OWNED BY public.binary_objects.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: swirlds
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO swirlds;

--
-- Name: binary_objects id; Type: DEFAULT; Schema: public; Owner: swirlds
--

ALTER TABLE ONLY public.binary_objects ALTER COLUMN id SET DEFAULT nextval('public.binary_objects_id_seq'::regclass);


--
-- Name: 16680; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16680');


ALTER LARGE OBJECT 16680 OWNER TO swirlds;

--
-- Name: 16682; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16682');


ALTER LARGE OBJECT 16682 OWNER TO swirlds;

--
-- Name: 16683; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16683');


ALTER LARGE OBJECT 16683 OWNER TO swirlds;

--
-- Name: 16685; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16685');


ALTER LARGE OBJECT 16685 OWNER TO swirlds;

--
-- Name: 16688; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16688');


ALTER LARGE OBJECT 16688 OWNER TO swirlds;

--
-- Name: 16689; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16689');


ALTER LARGE OBJECT 16689 OWNER TO swirlds;

--
-- Name: 16693; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16693');


ALTER LARGE OBJECT 16693 OWNER TO swirlds;

--
-- Name: 16695; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16695');


ALTER LARGE OBJECT 16695 OWNER TO swirlds;

--
-- Name: 16698; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16698');


ALTER LARGE OBJECT 16698 OWNER TO swirlds;

--
-- Name: 16699; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16699');


ALTER LARGE OBJECT 16699 OWNER TO swirlds;

--
-- Name: 16700; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16700');


ALTER LARGE OBJECT 16700 OWNER TO swirlds;

--
-- Name: 16702; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16702');


ALTER LARGE OBJECT 16702 OWNER TO swirlds;

--
-- Name: 16704; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16704');


ALTER LARGE OBJECT 16704 OWNER TO swirlds;

--
-- Name: 16707; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16707');


ALTER LARGE OBJECT 16707 OWNER TO swirlds;

--
-- Name: 16708; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16708');


ALTER LARGE OBJECT 16708 OWNER TO swirlds;

--
-- Name: 16712; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16712');


ALTER LARGE OBJECT 16712 OWNER TO swirlds;

--
-- Name: 16716; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16716');


ALTER LARGE OBJECT 16716 OWNER TO swirlds;

--
-- Name: 16717; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16717');


ALTER LARGE OBJECT 16717 OWNER TO swirlds;

--
-- Name: 16721; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16721');


ALTER LARGE OBJECT 16721 OWNER TO swirlds;

--
-- Name: 16725; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16725');


ALTER LARGE OBJECT 16725 OWNER TO swirlds;

--
-- Name: 16728; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16728');


ALTER LARGE OBJECT 16728 OWNER TO swirlds;

--
-- Name: 16729; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16729');


ALTER LARGE OBJECT 16729 OWNER TO swirlds;

--
-- Name: 16730; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16730');


ALTER LARGE OBJECT 16730 OWNER TO swirlds;

--
-- Name: 16731; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16731');


ALTER LARGE OBJECT 16731 OWNER TO swirlds;

--
-- Name: 16732; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16732');


ALTER LARGE OBJECT 16732 OWNER TO swirlds;

--
-- Name: 16734; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16734');


ALTER LARGE OBJECT 16734 OWNER TO swirlds;

--
-- Name: 16737; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16737');


ALTER LARGE OBJECT 16737 OWNER TO swirlds;

--
-- Name: 16738; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16738');


ALTER LARGE OBJECT 16738 OWNER TO swirlds;

--
-- Name: 16740; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16740');


ALTER LARGE OBJECT 16740 OWNER TO swirlds;

--
-- Name: 16744; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16744');


ALTER LARGE OBJECT 16744 OWNER TO swirlds;

--
-- Name: 16745; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16745');


ALTER LARGE OBJECT 16745 OWNER TO swirlds;

--
-- Name: 16746; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16746');


ALTER LARGE OBJECT 16746 OWNER TO swirlds;

--
-- Name: 16747; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16747');


ALTER LARGE OBJECT 16747 OWNER TO swirlds;

--
-- Name: 16748; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16748');


ALTER LARGE OBJECT 16748 OWNER TO swirlds;

--
-- Name: 16749; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16749');


ALTER LARGE OBJECT 16749 OWNER TO swirlds;

--
-- Name: 16755; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16755');


ALTER LARGE OBJECT 16755 OWNER TO swirlds;

--
-- Name: 16756; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16756');


ALTER LARGE OBJECT 16756 OWNER TO swirlds;

--
-- Name: 16757; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16757');


ALTER LARGE OBJECT 16757 OWNER TO swirlds;

--
-- Name: 16758; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16758');


ALTER LARGE OBJECT 16758 OWNER TO swirlds;

--
-- Name: 16759; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16759');


ALTER LARGE OBJECT 16759 OWNER TO swirlds;

--
-- Name: 16760; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16760');


ALTER LARGE OBJECT 16760 OWNER TO swirlds;

--
-- Name: 16761; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16761');


ALTER LARGE OBJECT 16761 OWNER TO swirlds;

--
-- Name: 16762; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16762');


ALTER LARGE OBJECT 16762 OWNER TO swirlds;

--
-- Name: 16764; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16764');


ALTER LARGE OBJECT 16764 OWNER TO swirlds;

--
-- Name: 16765; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16765');


ALTER LARGE OBJECT 16765 OWNER TO swirlds;

--
-- Name: 16766; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16766');


ALTER LARGE OBJECT 16766 OWNER TO swirlds;

--
-- Name: 16767; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16767');


ALTER LARGE OBJECT 16767 OWNER TO swirlds;

--
-- Name: 16768; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16768');


ALTER LARGE OBJECT 16768 OWNER TO swirlds;

--
-- Name: 16769; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16769');


ALTER LARGE OBJECT 16769 OWNER TO swirlds;

--
-- Name: 16771; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16771');


ALTER LARGE OBJECT 16771 OWNER TO swirlds;

--
-- Name: 16774; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16774');


ALTER LARGE OBJECT 16774 OWNER TO swirlds;

--
-- Name: 16775; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16775');


ALTER LARGE OBJECT 16775 OWNER TO swirlds;

--
-- Name: 16776; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16776');


ALTER LARGE OBJECT 16776 OWNER TO swirlds;

--
-- Name: 16777; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16777');


ALTER LARGE OBJECT 16777 OWNER TO swirlds;

--
-- Name: 16778; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16778');


ALTER LARGE OBJECT 16778 OWNER TO swirlds;

--
-- Name: 16779; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16779');


ALTER LARGE OBJECT 16779 OWNER TO swirlds;

--
-- Name: 16780; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16780');


ALTER LARGE OBJECT 16780 OWNER TO swirlds;

--
-- Name: 16781; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16781');


ALTER LARGE OBJECT 16781 OWNER TO swirlds;

--
-- Name: 16782; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16782');


ALTER LARGE OBJECT 16782 OWNER TO swirlds;

--
-- Name: 16783; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16783');


ALTER LARGE OBJECT 16783 OWNER TO swirlds;

--
-- Name: 16784; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16784');


ALTER LARGE OBJECT 16784 OWNER TO swirlds;

--
-- Name: 16786; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16786');


ALTER LARGE OBJECT 16786 OWNER TO swirlds;

--
-- Name: 16787; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16787');


ALTER LARGE OBJECT 16787 OWNER TO swirlds;

--
-- Name: 16788; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16788');


ALTER LARGE OBJECT 16788 OWNER TO swirlds;

--
-- Name: 16790; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16790');


ALTER LARGE OBJECT 16790 OWNER TO swirlds;

--
-- Name: 16794; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16794');


ALTER LARGE OBJECT 16794 OWNER TO swirlds;

--
-- Name: 16795; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16795');


ALTER LARGE OBJECT 16795 OWNER TO swirlds;

--
-- Name: 16796; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16796');


ALTER LARGE OBJECT 16796 OWNER TO swirlds;

--
-- Name: 16798; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16798');


ALTER LARGE OBJECT 16798 OWNER TO swirlds;

--
-- Name: 16799; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16799');


ALTER LARGE OBJECT 16799 OWNER TO swirlds;

--
-- Name: 16800; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16800');


ALTER LARGE OBJECT 16800 OWNER TO swirlds;

--
-- Name: 16801; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16801');


ALTER LARGE OBJECT 16801 OWNER TO swirlds;

--
-- Name: 16802; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16802');


ALTER LARGE OBJECT 16802 OWNER TO swirlds;

--
-- Name: 16803; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16803');


ALTER LARGE OBJECT 16803 OWNER TO swirlds;

--
-- Name: 16804; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16804');


ALTER LARGE OBJECT 16804 OWNER TO swirlds;

--
-- Name: 16806; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16806');


ALTER LARGE OBJECT 16806 OWNER TO swirlds;

--
-- Name: 16807; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16807');


ALTER LARGE OBJECT 16807 OWNER TO swirlds;

--
-- Name: 16808; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16808');


ALTER LARGE OBJECT 16808 OWNER TO swirlds;

--
-- Name: 16809; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16809');


ALTER LARGE OBJECT 16809 OWNER TO swirlds;

--
-- Name: 16811; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16811');


ALTER LARGE OBJECT 16811 OWNER TO swirlds;

--
-- Name: 16812; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16812');


ALTER LARGE OBJECT 16812 OWNER TO swirlds;

--
-- Name: 16813; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16813');


ALTER LARGE OBJECT 16813 OWNER TO swirlds;

--
-- Name: 16815; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16815');


ALTER LARGE OBJECT 16815 OWNER TO swirlds;

--
-- Name: 16831; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16831');


ALTER LARGE OBJECT 16831 OWNER TO swirlds;

--
-- Name: 16832; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16832');


ALTER LARGE OBJECT 16832 OWNER TO swirlds;

--
-- Name: 16833; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16833');


ALTER LARGE OBJECT 16833 OWNER TO swirlds;

--
-- Name: 16857; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16857');


ALTER LARGE OBJECT 16857 OWNER TO swirlds;

--
-- Name: 16858; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16858');


ALTER LARGE OBJECT 16858 OWNER TO swirlds;

--
-- Name: 16860; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16860');


ALTER LARGE OBJECT 16860 OWNER TO swirlds;

--
-- Name: 16862; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16862');


ALTER LARGE OBJECT 16862 OWNER TO swirlds;

--
-- Name: 16863; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16863');


ALTER LARGE OBJECT 16863 OWNER TO swirlds;

--
-- Name: 16864; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16864');


ALTER LARGE OBJECT 16864 OWNER TO swirlds;

--
-- Name: 16866; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16866');


ALTER LARGE OBJECT 16866 OWNER TO swirlds;

--
-- Name: 16867; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16867');


ALTER LARGE OBJECT 16867 OWNER TO swirlds;

--
-- Name: 16868; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16868');


ALTER LARGE OBJECT 16868 OWNER TO swirlds;

--
-- Name: 16869; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16869');


ALTER LARGE OBJECT 16869 OWNER TO swirlds;

--
-- Name: 16870; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16870');


ALTER LARGE OBJECT 16870 OWNER TO swirlds;

--
-- Name: 16871; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16871');


ALTER LARGE OBJECT 16871 OWNER TO swirlds;

--
-- Name: 16872; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16872');


ALTER LARGE OBJECT 16872 OWNER TO swirlds;

--
-- Name: 16873; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16873');


ALTER LARGE OBJECT 16873 OWNER TO swirlds;

--
-- Name: 16874; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16874');


ALTER LARGE OBJECT 16874 OWNER TO swirlds;

--
-- Name: 16875; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16875');


ALTER LARGE OBJECT 16875 OWNER TO swirlds;

--
-- Name: 16876; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16876');


ALTER LARGE OBJECT 16876 OWNER TO swirlds;

--
-- Name: 16877; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16877');


ALTER LARGE OBJECT 16877 OWNER TO swirlds;

--
-- Name: 16878; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16878');


ALTER LARGE OBJECT 16878 OWNER TO swirlds;

--
-- Name: 16879; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16879');


ALTER LARGE OBJECT 16879 OWNER TO swirlds;

--
-- Name: 16880; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16880');


ALTER LARGE OBJECT 16880 OWNER TO swirlds;

--
-- Name: 16881; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16881');


ALTER LARGE OBJECT 16881 OWNER TO swirlds;

--
-- Name: 16882; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16882');


ALTER LARGE OBJECT 16882 OWNER TO swirlds;

--
-- Name: 16883; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16883');


ALTER LARGE OBJECT 16883 OWNER TO swirlds;

--
-- Name: 16884; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16884');


ALTER LARGE OBJECT 16884 OWNER TO swirlds;

--
-- Name: 16885; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16885');


ALTER LARGE OBJECT 16885 OWNER TO swirlds;

--
-- Name: 16886; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16886');


ALTER LARGE OBJECT 16886 OWNER TO swirlds;

--
-- Name: 16887; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16887');


ALTER LARGE OBJECT 16887 OWNER TO swirlds;

--
-- Name: 16888; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16888');


ALTER LARGE OBJECT 16888 OWNER TO swirlds;

--
-- Name: 16889; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16889');


ALTER LARGE OBJECT 16889 OWNER TO swirlds;

--
-- Name: 16890; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16890');


ALTER LARGE OBJECT 16890 OWNER TO swirlds;

--
-- Name: 16892; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16892');


ALTER LARGE OBJECT 16892 OWNER TO swirlds;

--
-- Name: 16893; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16893');


ALTER LARGE OBJECT 16893 OWNER TO swirlds;

--
-- Name: 16894; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16894');


ALTER LARGE OBJECT 16894 OWNER TO swirlds;

--
-- Name: 16895; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16895');


ALTER LARGE OBJECT 16895 OWNER TO swirlds;

--
-- Name: 16896; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16896');


ALTER LARGE OBJECT 16896 OWNER TO swirlds;

--
-- Name: 16897; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16897');


ALTER LARGE OBJECT 16897 OWNER TO swirlds;

--
-- Name: 16898; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16898');


ALTER LARGE OBJECT 16898 OWNER TO swirlds;

--
-- Name: 16899; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16899');


ALTER LARGE OBJECT 16899 OWNER TO swirlds;

--
-- Name: 16900; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16900');


ALTER LARGE OBJECT 16900 OWNER TO swirlds;

--
-- Name: 16901; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16901');


ALTER LARGE OBJECT 16901 OWNER TO swirlds;

--
-- Name: 16902; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16902');


ALTER LARGE OBJECT 16902 OWNER TO swirlds;

--
-- Name: 16903; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16903');


ALTER LARGE OBJECT 16903 OWNER TO swirlds;

--
-- Name: 16904; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16904');


ALTER LARGE OBJECT 16904 OWNER TO swirlds;

--
-- Name: 16905; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16905');


ALTER LARGE OBJECT 16905 OWNER TO swirlds;

--
-- Name: 16909; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16909');


ALTER LARGE OBJECT 16909 OWNER TO swirlds;

--
-- Name: 16911; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16911');


ALTER LARGE OBJECT 16911 OWNER TO swirlds;

--
-- Name: 16912; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16912');


ALTER LARGE OBJECT 16912 OWNER TO swirlds;

--
-- Name: 16913; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16913');


ALTER LARGE OBJECT 16913 OWNER TO swirlds;

--
-- Name: 16915; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16915');


ALTER LARGE OBJECT 16915 OWNER TO swirlds;

--
-- Name: 16922; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16922');


ALTER LARGE OBJECT 16922 OWNER TO swirlds;

--
-- Name: 16923; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16923');


ALTER LARGE OBJECT 16923 OWNER TO swirlds;

--
-- Name: 16924; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16924');


ALTER LARGE OBJECT 16924 OWNER TO swirlds;

--
-- Name: 16926; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16926');


ALTER LARGE OBJECT 16926 OWNER TO swirlds;

--
-- Name: 16927; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16927');


ALTER LARGE OBJECT 16927 OWNER TO swirlds;

--
-- Name: 16928; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16928');


ALTER LARGE OBJECT 16928 OWNER TO swirlds;

--
-- Name: 16929; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16929');


ALTER LARGE OBJECT 16929 OWNER TO swirlds;

--
-- Name: 16930; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16930');


ALTER LARGE OBJECT 16930 OWNER TO swirlds;

--
-- Name: 16931; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16931');


ALTER LARGE OBJECT 16931 OWNER TO swirlds;

--
-- Name: 16933; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16933');


ALTER LARGE OBJECT 16933 OWNER TO swirlds;

--
-- Name: 16935; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16935');


ALTER LARGE OBJECT 16935 OWNER TO swirlds;

--
-- Name: 16936; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16936');


ALTER LARGE OBJECT 16936 OWNER TO swirlds;

--
-- Name: 16937; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16937');


ALTER LARGE OBJECT 16937 OWNER TO swirlds;

--
-- Name: 16938; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16938');


ALTER LARGE OBJECT 16938 OWNER TO swirlds;

--
-- Name: 16939; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16939');


ALTER LARGE OBJECT 16939 OWNER TO swirlds;

--
-- Name: 16940; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16940');


ALTER LARGE OBJECT 16940 OWNER TO swirlds;

--
-- Name: 16941; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16941');


ALTER LARGE OBJECT 16941 OWNER TO swirlds;

--
-- Name: 16942; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16942');


ALTER LARGE OBJECT 16942 OWNER TO swirlds;

--
-- Name: 16943; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16943');


ALTER LARGE OBJECT 16943 OWNER TO swirlds;

--
-- Name: 16944; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16944');


ALTER LARGE OBJECT 16944 OWNER TO swirlds;

--
-- Name: 16945; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16945');


ALTER LARGE OBJECT 16945 OWNER TO swirlds;

--
-- Name: 16947; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16947');


ALTER LARGE OBJECT 16947 OWNER TO swirlds;

--
-- Name: 16948; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16948');


ALTER LARGE OBJECT 16948 OWNER TO swirlds;

--
-- Name: 16949; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16949');


ALTER LARGE OBJECT 16949 OWNER TO swirlds;

--
-- Name: 16950; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16950');


ALTER LARGE OBJECT 16950 OWNER TO swirlds;

--
-- Name: 16951; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16951');


ALTER LARGE OBJECT 16951 OWNER TO swirlds;

--
-- Name: 16952; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16952');


ALTER LARGE OBJECT 16952 OWNER TO swirlds;

--
-- Name: 16953; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16953');


ALTER LARGE OBJECT 16953 OWNER TO swirlds;

--
-- Name: 16955; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16955');


ALTER LARGE OBJECT 16955 OWNER TO swirlds;

--
-- Name: 16956; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16956');


ALTER LARGE OBJECT 16956 OWNER TO swirlds;

--
-- Name: 16957; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16957');


ALTER LARGE OBJECT 16957 OWNER TO swirlds;

--
-- Name: 16958; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16958');


ALTER LARGE OBJECT 16958 OWNER TO swirlds;

--
-- Name: 16959; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16959');


ALTER LARGE OBJECT 16959 OWNER TO swirlds;

--
-- Name: 16960; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16960');


ALTER LARGE OBJECT 16960 OWNER TO swirlds;

--
-- Name: 16961; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16961');


ALTER LARGE OBJECT 16961 OWNER TO swirlds;

--
-- Name: 16965; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16965');


ALTER LARGE OBJECT 16965 OWNER TO swirlds;

--
-- Name: 16966; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16966');


ALTER LARGE OBJECT 16966 OWNER TO swirlds;

--
-- Name: 16967; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16967');


ALTER LARGE OBJECT 16967 OWNER TO swirlds;

--
-- Name: 16969; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16969');


ALTER LARGE OBJECT 16969 OWNER TO swirlds;

--
-- Name: 16973; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16973');


ALTER LARGE OBJECT 16973 OWNER TO swirlds;

--
-- Name: 16974; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16974');


ALTER LARGE OBJECT 16974 OWNER TO swirlds;

--
-- Name: 16975; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16975');


ALTER LARGE OBJECT 16975 OWNER TO swirlds;

--
-- Name: 16976; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16976');


ALTER LARGE OBJECT 16976 OWNER TO swirlds;

--
-- Name: 16977; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16977');


ALTER LARGE OBJECT 16977 OWNER TO swirlds;

--
-- Name: 16978; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16978');


ALTER LARGE OBJECT 16978 OWNER TO swirlds;

--
-- Name: 16979; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16979');


ALTER LARGE OBJECT 16979 OWNER TO swirlds;

--
-- Name: 16980; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16980');


ALTER LARGE OBJECT 16980 OWNER TO swirlds;

--
-- Name: 16981; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16981');


ALTER LARGE OBJECT 16981 OWNER TO swirlds;

--
-- Name: 16983; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16983');


ALTER LARGE OBJECT 16983 OWNER TO swirlds;

--
-- Name: 16984; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16984');


ALTER LARGE OBJECT 16984 OWNER TO swirlds;

--
-- Name: 16985; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16985');


ALTER LARGE OBJECT 16985 OWNER TO swirlds;

--
-- Name: 16994; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16994');


ALTER LARGE OBJECT 16994 OWNER TO swirlds;

--
-- Name: 16995; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16995');


ALTER LARGE OBJECT 16995 OWNER TO swirlds;

--
-- Name: 16997; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16997');


ALTER LARGE OBJECT 16997 OWNER TO swirlds;

--
-- Name: 16998; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('16998');


ALTER LARGE OBJECT 16998 OWNER TO swirlds;

--
-- Name: 17000; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17000');


ALTER LARGE OBJECT 17000 OWNER TO swirlds;

--
-- Name: 17014; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17014');


ALTER LARGE OBJECT 17014 OWNER TO swirlds;

--
-- Name: 17015; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17015');


ALTER LARGE OBJECT 17015 OWNER TO swirlds;

--
-- Name: 17028; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17028');


ALTER LARGE OBJECT 17028 OWNER TO swirlds;

--
-- Name: 17029; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17029');


ALTER LARGE OBJECT 17029 OWNER TO swirlds;

--
-- Name: 17030; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17030');


ALTER LARGE OBJECT 17030 OWNER TO swirlds;

--
-- Name: 17031; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17031');


ALTER LARGE OBJECT 17031 OWNER TO swirlds;

--
-- Name: 17032; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17032');


ALTER LARGE OBJECT 17032 OWNER TO swirlds;

--
-- Name: 17033; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17033');


ALTER LARGE OBJECT 17033 OWNER TO swirlds;

--
-- Name: 17034; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17034');


ALTER LARGE OBJECT 17034 OWNER TO swirlds;

--
-- Name: 17035; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17035');


ALTER LARGE OBJECT 17035 OWNER TO swirlds;

--
-- Name: 17036; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17036');


ALTER LARGE OBJECT 17036 OWNER TO swirlds;

--
-- Name: 17058; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17058');


ALTER LARGE OBJECT 17058 OWNER TO swirlds;

--
-- Name: 17060; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17060');


ALTER LARGE OBJECT 17060 OWNER TO swirlds;

--
-- Name: 17074; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17074');


ALTER LARGE OBJECT 17074 OWNER TO swirlds;

--
-- Name: 17075; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17075');


ALTER LARGE OBJECT 17075 OWNER TO swirlds;

--
-- Name: 17077; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17077');


ALTER LARGE OBJECT 17077 OWNER TO swirlds;

--
-- Name: 17078; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17078');


ALTER LARGE OBJECT 17078 OWNER TO swirlds;

--
-- Name: 17079; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17079');


ALTER LARGE OBJECT 17079 OWNER TO swirlds;

--
-- Name: 17080; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17080');


ALTER LARGE OBJECT 17080 OWNER TO swirlds;

--
-- Name: 17081; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17081');


ALTER LARGE OBJECT 17081 OWNER TO swirlds;

--
-- Name: 17083; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17083');


ALTER LARGE OBJECT 17083 OWNER TO swirlds;

--
-- Name: 17089; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17089');


ALTER LARGE OBJECT 17089 OWNER TO swirlds;

--
-- Name: 17091; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17091');


ALTER LARGE OBJECT 17091 OWNER TO swirlds;

--
-- Name: 17094; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17094');


ALTER LARGE OBJECT 17094 OWNER TO swirlds;

--
-- Name: 17099; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17099');


ALTER LARGE OBJECT 17099 OWNER TO swirlds;

--
-- Name: 17100; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17100');


ALTER LARGE OBJECT 17100 OWNER TO swirlds;

--
-- Name: 17101; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17101');


ALTER LARGE OBJECT 17101 OWNER TO swirlds;

--
-- Name: 17102; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17102');


ALTER LARGE OBJECT 17102 OWNER TO swirlds;

--
-- Name: 17218; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17218');


ALTER LARGE OBJECT 17218 OWNER TO swirlds;

--
-- Name: 17219; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17219');


ALTER LARGE OBJECT 17219 OWNER TO swirlds;

--
-- Name: 17220; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17220');


ALTER LARGE OBJECT 17220 OWNER TO swirlds;

--
-- Name: 17266; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17266');


ALTER LARGE OBJECT 17266 OWNER TO swirlds;

--
-- Name: 17267; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17267');


ALTER LARGE OBJECT 17267 OWNER TO swirlds;

--
-- Name: 17277; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17277');


ALTER LARGE OBJECT 17277 OWNER TO swirlds;

--
-- Name: 17291; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17291');


ALTER LARGE OBJECT 17291 OWNER TO swirlds;

--
-- Name: 17292; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17292');


ALTER LARGE OBJECT 17292 OWNER TO swirlds;

--
-- Name: 17293; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17293');


ALTER LARGE OBJECT 17293 OWNER TO swirlds;

--
-- Name: 17294; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17294');


ALTER LARGE OBJECT 17294 OWNER TO swirlds;

--
-- Name: 17295; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17295');


ALTER LARGE OBJECT 17295 OWNER TO swirlds;

--
-- Name: 17296; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17296');


ALTER LARGE OBJECT 17296 OWNER TO swirlds;

--
-- Name: 17299; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17299');


ALTER LARGE OBJECT 17299 OWNER TO swirlds;

--
-- Name: 17300; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17300');


ALTER LARGE OBJECT 17300 OWNER TO swirlds;

--
-- Name: 17301; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17301');


ALTER LARGE OBJECT 17301 OWNER TO swirlds;

--
-- Name: 17305; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17305');


ALTER LARGE OBJECT 17305 OWNER TO swirlds;

--
-- Name: 17325; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17325');


ALTER LARGE OBJECT 17325 OWNER TO swirlds;

--
-- Name: 17327; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17327');


ALTER LARGE OBJECT 17327 OWNER TO swirlds;

--
-- Name: 17341; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17341');


ALTER LARGE OBJECT 17341 OWNER TO swirlds;

--
-- Name: 17342; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17342');


ALTER LARGE OBJECT 17342 OWNER TO swirlds;

--
-- Name: 17343; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17343');


ALTER LARGE OBJECT 17343 OWNER TO swirlds;

--
-- Name: 17344; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17344');


ALTER LARGE OBJECT 17344 OWNER TO swirlds;

--
-- Name: 17435; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17435');


ALTER LARGE OBJECT 17435 OWNER TO swirlds;

--
-- Name: 17437; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17437');


ALTER LARGE OBJECT 17437 OWNER TO swirlds;

--
-- Name: 17500; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17500');


ALTER LARGE OBJECT 17500 OWNER TO swirlds;

--
-- Name: 17501; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17501');


ALTER LARGE OBJECT 17501 OWNER TO swirlds;

--
-- Name: 17502; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17502');


ALTER LARGE OBJECT 17502 OWNER TO swirlds;

--
-- Name: 17503; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17503');


ALTER LARGE OBJECT 17503 OWNER TO swirlds;

--
-- Name: 17504; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17504');


ALTER LARGE OBJECT 17504 OWNER TO swirlds;

--
-- Name: 17505; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17505');


ALTER LARGE OBJECT 17505 OWNER TO swirlds;

--
-- Name: 17506; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17506');


ALTER LARGE OBJECT 17506 OWNER TO swirlds;

--
-- Name: 17507; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17507');


ALTER LARGE OBJECT 17507 OWNER TO swirlds;

--
-- Name: 17508; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17508');


ALTER LARGE OBJECT 17508 OWNER TO swirlds;

--
-- Name: 17509; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17509');


ALTER LARGE OBJECT 17509 OWNER TO swirlds;

--
-- Name: 17515; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17515');


ALTER LARGE OBJECT 17515 OWNER TO swirlds;

--
-- Name: 17520; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17520');


ALTER LARGE OBJECT 17520 OWNER TO swirlds;

--
-- Name: 17521; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17521');


ALTER LARGE OBJECT 17521 OWNER TO swirlds;

--
-- Name: 17522; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17522');


ALTER LARGE OBJECT 17522 OWNER TO swirlds;

--
-- Name: 17526; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17526');


ALTER LARGE OBJECT 17526 OWNER TO swirlds;

--
-- Name: 17528; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17528');


ALTER LARGE OBJECT 17528 OWNER TO swirlds;

--
-- Name: 17533; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17533');


ALTER LARGE OBJECT 17533 OWNER TO swirlds;

--
-- Name: 17534; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17534');


ALTER LARGE OBJECT 17534 OWNER TO swirlds;

--
-- Name: 17535; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17535');


ALTER LARGE OBJECT 17535 OWNER TO swirlds;

--
-- Name: 17538; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17538');


ALTER LARGE OBJECT 17538 OWNER TO swirlds;

--
-- Name: 17540; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17540');


ALTER LARGE OBJECT 17540 OWNER TO swirlds;

--
-- Name: 17542; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17542');


ALTER LARGE OBJECT 17542 OWNER TO swirlds;

--
-- Name: 17544; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17544');


ALTER LARGE OBJECT 17544 OWNER TO swirlds;

--
-- Name: 17546; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17546');


ALTER LARGE OBJECT 17546 OWNER TO swirlds;

--
-- Name: 17552; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17552');


ALTER LARGE OBJECT 17552 OWNER TO swirlds;

--
-- Name: 17558; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17558');


ALTER LARGE OBJECT 17558 OWNER TO swirlds;

--
-- Name: 17560; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17560');


ALTER LARGE OBJECT 17560 OWNER TO swirlds;

--
-- Name: 17561; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17561');


ALTER LARGE OBJECT 17561 OWNER TO swirlds;

--
-- Name: 17562; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17562');


ALTER LARGE OBJECT 17562 OWNER TO swirlds;

--
-- Name: 17563; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17563');


ALTER LARGE OBJECT 17563 OWNER TO swirlds;

--
-- Name: 17565; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17565');


ALTER LARGE OBJECT 17565 OWNER TO swirlds;

--
-- Name: 17566; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17566');


ALTER LARGE OBJECT 17566 OWNER TO swirlds;

--
-- Name: 17569; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17569');


ALTER LARGE OBJECT 17569 OWNER TO swirlds;

--
-- Name: 17574; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17574');


ALTER LARGE OBJECT 17574 OWNER TO swirlds;

--
-- Name: 17575; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17575');


ALTER LARGE OBJECT 17575 OWNER TO swirlds;

--
-- Name: 17576; Type: BLOB; Schema: -; Owner: swirlds
--

SELECT pg_catalog.lo_create('17576');


ALTER LARGE OBJECT 17576 OWNER TO swirlds;

--
-- Data for Name: binary_objects; Type: TABLE DATA; Schema: public; Owner: swirlds
--

COPY public.binary_objects (id, ref_count, hash, file_oid) FROM stdin;
\.
COPY public.binary_objects (id, ref_count, hash, file_oid) FROM '$$PATH$$/2950.dat';

--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: swirlds
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
\.
COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM '$$PATH$$/2952.dat';

--
-- Name: binary_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: swirlds
--

SELECT pg_catalog.setval('public.binary_objects_id_seq', 872, true);


--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: 
--

\i $$PATH$$/3233.dat

--
-- Name: binary_objects binary_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: swirlds
--

ALTER TABLE ONLY public.binary_objects
    ADD CONSTRAINT binary_objects_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: swirlds
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: swirlds
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: uidx_binary_objects_hash; Type: INDEX; Schema: public; Owner: swirlds
--

CREATE UNIQUE INDEX uidx_binary_objects_hash ON public.binary_objects USING btree (hash);


--
-- Name: uidx_binary_objects_ref_count; Type: INDEX; Schema: public; Owner: swirlds
--

CREATE INDEX uidx_binary_objects_ref_count ON public.binary_objects USING btree (ref_count);


--
-- PostgreSQL database dump complete
--

